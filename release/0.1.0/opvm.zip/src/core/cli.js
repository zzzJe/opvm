import cli from './../command/_index.js';
import './../command/search.js';
import './../command/install.js';
import './../command/uninstall.js';
import './../command/list.js';
import './../command/use.js';
import './../command/config.js';

export default cli;
