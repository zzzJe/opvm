import cli from './core/cli.js';

cli.parse(process.argv);
