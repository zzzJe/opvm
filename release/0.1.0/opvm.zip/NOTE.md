header  := html -> body -> table -> (tbody) -> tr[0] -> td
content := html -> body -> table -> (tbody) -> tr[1] -> td -> span
footer  := html -> body -> table -> (tbody) -> tr[2] -> td

## architecture

- use `https://optifine.net/downloads` to check downloadable contents
- use `https://optifine.net/adloadx?f=<{package_name}.jar>` to download contents

## for list downloadable packages

- content
  - script := show_spoiler
  - h2  := version
  - a   := [+/- Preview versions]
  - div := container of downloadable list
    - table.downloadTable
      - tbody
        - tr* (for download per version)
          - td.colFile      := package name
          - td.colDownload  := 
            - a
          - td.colMirror    := 
          - td.colChangelog := 
          - td.colForge     := 
          - td.colDate      := 
        

